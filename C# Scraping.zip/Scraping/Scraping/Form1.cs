﻿using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebDriverManager.DriverConfigs.Impl;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Threading;
using CsvHelper;
using System.IO;
using System.Globalization;

namespace Scraping
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            Task task = Task.Run((System.Action)MigrateTask);
        }

        public void MigrateTask()
        {
            new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());
            ChromeDriver driver = new ChromeDriver();
            string url = "https://www.foxsports.com.au/nrl/nrl-premiership/stats/players?editiondata=none&fromakamai=true&pt=none&device=DESKTOP&wpa=BB44D82C3D7223D393F2AE47579FB5EA6791ABE4&pageNumber=";
            driver.Url = "https://www.foxsports.com.au/nrl/nrl-premiership/stats/players?editiondata=none&fromakamai=true&pt=none&device=DESKTOP&wpa=BB44D82C3D7223D393F2AE47579FB5EA6791ABE4&pageNumber=1";
            var htmlDoc = new HtmlAgilityPack.HtmlDocument();
            string htmlCode = "";

            try
            {
                Thread.Sleep(700);
                htmlCode = driver.PageSource;
                if (htmlCode == null || htmlCode.Length <= 0)
                {
                    return;
                }

                htmlDoc.LoadHtml(htmlCode);
                IList<HtmlNode> nodes = htmlDoc.QuerySelectorAll("thead span");

                using (var mem = new MemoryStream())
                using (var writer = new StreamWriter(@"Result.csv"))
                using (var csvWriter = new CsvWriter(writer, CultureInfo.CurrentCulture))
                {
                    foreach (HtmlNode node in nodes)
                    {
                        if (node.InnerText != "")
                        {
                            csvWriter.WriteField(node.InnerText);
                        }
                    }
                    csvWriter.NextRecord();

                    for (int i = 1; i <= 21; i++)
                    {
                        bool bFlag = true;
                        driver.Url = url + i.ToString();
                        Thread.Sleep(700);
                        htmlCode = "";
                        htmlCode = driver.PageSource;
                        if (htmlCode == null || htmlCode.Length <= 0)
                        {
                            continue;
                        }
                        htmlDoc.LoadHtml(htmlCode);
                        nodes = htmlDoc.QuerySelectorAll("table.fiso-lab-table tr");
                        foreach (HtmlNode node in nodes)
                        {
                            if (bFlag == true)
                            {
                                bFlag = false;
                                continue;
                            }
                            String row = node.InnerHtml;
                            var htmlDocRow = new HtmlAgilityPack.HtmlDocument();
                            htmlDocRow.LoadHtml(row);

                            string name = "";
                            if (htmlDocRow.QuerySelectorAll("th, span[class=\"fiso-lab-table__row-heading-primary-data\"]").Count > 0)
                            {
                                name += htmlDocRow.QuerySelectorAll("th, span[class=\"fiso-lab-table__row-heading-primary-data\"]").First().InnerText;
                            }
                            csvWriter.WriteField(name);
                            IList<HtmlNode> rowTemp = htmlDocRow.QuerySelectorAll("td");
                            foreach (HtmlNode nodeTemp in rowTemp)
                            {
                                csvWriter.WriteField(nodeTemp.InnerText);
                            }
                            csvWriter.NextRecord();
                        }
                    }
                    writer.Flush();
                }
            }
            catch 
            { 
            }
            driver.Close();
        }
    }
}
